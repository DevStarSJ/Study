import json
from router import router

def handler(event, context):
    result = router(event);
    return { 'body' : json.dumps(result) }